import _ from 'lodash';

// Array of available nodes to connect to
export const nodes = [process.env.REACT_APP_NODE];

const getNodeUrl = () => {
  return _.sample(nodes);
};

export default getNodeUrl;
