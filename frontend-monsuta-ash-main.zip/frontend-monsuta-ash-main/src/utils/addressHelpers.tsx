import addresses from '../config/constants/contracts';

export const getAddress = (address: { [key: number]: string }) => {
  const chainId = parseInt(process.env.REACT_APP_NETWORK_ID || '10', 10);
  return address[chainId] ? address[chainId] : address[1];
};

export const getMulticallAddress = () => {
  return getAddress(addresses.multiCall);
};

export const getMonsutaAddress = () => {
  return getAddress(addresses.monsuta);
};

export const getRegistryAddress = () => {
  return getAddress(addresses.registry);
};

export const getFavorAddress = () => {
  return getAddress(addresses.favor);
};
