import { ethers, utils } from 'ethers';
import { Web3Provider, JsonRpcSigner, JsonRpcProvider } from '@ethersproject/providers';

import MulticallABI from '../config/abi/Multicall.json';
import MonsutaABI from '../config/abi/Monsuta.json';
import RegistryABI from '../config/abi/MonsutaRegistry.json';
import ERC20ABI from '../config/abi/erc20.json';

import { getMonsutaAddress, getRegistryAddress, getMulticallAddress, getFavorAddress } from './addressHelpers';
import getNodeUrl from './getRpcUrl';
import { getMerkleProof } from './merkle';
import { isAddress } from '.';
import axios from 'axios';

export const simpleRpcProvider = new ethers.providers.JsonRpcProvider(getNodeUrl());

export const getContract = (address: string, abi: any, signer?: Web3Provider | JsonRpcSigner | JsonRpcProvider) => {
  const signerOrProvider = signer ? signer : simpleRpcProvider;
  return new ethers.Contract(address, abi, signerOrProvider);
};

export const getMulticallContract = (provider?: Web3Provider | JsonRpcSigner | JsonRpcProvider) => {
  return getContract(getMulticallAddress(), MulticallABI, provider);
};

// Get NFT Contract
export const getMonsutaContract = (provider?: Web3Provider | JsonRpcSigner | JsonRpcProvider) => {
  return getContract(getMonsutaAddress(), MonsutaABI, provider);
};

export const getRegistryContract = (provider?: Web3Provider | JsonRpcSigner | JsonRpcProvider) => {
  return getContract(getRegistryAddress(), RegistryABI, provider);
};

export const getTokenContract = (currency: string, provider?: Web3Provider | JsonRpcSigner | JsonRpcProvider) => {
  return getContract(currency, ERC20ABI, provider);
};

export const getFavorContract = (provider?: Web3Provider | JsonRpcSigner | JsonRpcProvider) => {
  return getContract(getFavorAddress(), ERC20ABI, provider);
};

export const mint = async (numToMint: number, signer: JsonRpcSigner) => {
  const nftContract = getMonsutaContract(signer);

  try {
    const account = await signer.getAddress();

    const price = 1000;

    const balance = await signer.getBalance();
    if (balance.lte(price)) {
      throw new Error('Insufficient funds!');
    }

    let gasPrice = await signer.getGasPrice();
    if (gasPrice.lt(utils.parseUnits('20', 'gwei'))) {
      gasPrice = utils.parseUnits('20', 'gwei');
    }

    const gasLimit = await nftContract.estimateGas.mint(numToMint, {
      value: price,
    });

    const tx = await nftContract.mint(numToMint, {
      value: price,
      gasLimit: gasLimit.mul(140).div(100),
      gasPrice: gasPrice.mul(120).div(100),
    });
    const receipt = await tx.wait(1);

    return {
      transactionHash: receipt.transactionHash,
      error: null,
    };
  } catch (e: any) {
    const message = e?.message;
    throw new Error(message ? (message.length > 100 ? message.slice(0, 100) + '...' : message) : 'Failed Transaction!');
  }
};
