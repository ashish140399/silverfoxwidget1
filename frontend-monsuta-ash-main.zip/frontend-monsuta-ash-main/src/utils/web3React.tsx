import { InjectedConnector } from '@web3-react/injected-connector';
import { WalletConnectConnector } from '@web3-react/walletconnect-connector';
import { ethers } from 'ethers';
import getNodeUrl from './getRpcUrl';
import { WalletLinkConnector } from '@web3-react/walletlink-connector';

const POLLING_INTERVAL = 12000;
const rpcUrl = getNodeUrl();
const chainId = parseInt(process.env.REACT_APP_NETWORK_ID || '10', 5);

export enum ConnectorNames {
  Injected = 'Injected',
  WalletConnect = 'WalletConnect',
  WalletLink = 'WalletLink',
}

export const injected = new InjectedConnector({ supportedChainIds: [1, 5] });

export const walletconnect = new WalletConnectConnector({
  rpc: { [chainId]: rpcUrl },
  qrcode: true,
});

// mainnet only
export const walletlink = new WalletLinkConnector({
  url: rpcUrl,
  appName: 'Monsuta',
});

export const connectorsByName = {
  Injected: injected,
  WalletConnect: walletconnect,
  WalletLink: walletlink,
};

export const connectors =
  +chainId === 10
    ? [
        {
          title: 'Metamask',
          connectorId: 'Injected',
        },
        {
          title: 'WalletConnect',
          connectorId: 'WalletConnect',
        },
      ]
    : [
        {
          title: 'Metamask',
          connectorId: 'Injected',
        },
        {
          title: 'WalletConnect',
          connectorId: 'WalletConnect',
        },
      ];

export const getLibrary = provider => {
  const library = new ethers.providers.Web3Provider(provider);
  library.pollingInterval = POLLING_INTERVAL;
  return library;
};

/**
 * BSC Wallet requires a different sign method
 * @see https://docs.binance.org/smart-chain/wallet/wallet_api.html#binancechainbnbsignaddress-string-message-string-promisepublickey-string-signature-string
 */
declare const window: any;
export const signMessage = async (provider, account, message) => {
  if (window.BinanceChain) {
    const { signature } = await window.BinanceChain.bnbSign(account, message);
    return signature;
  }

  /**
   * Wallet Connect does not sign the message correctly unless you use their method
   * @see https://github.com/WalletConnect/walletconnect-monorepo/issues/462
   */
  if (provider.provider.wc) {
    const wcMessage = ethers.utils.hexlify(ethers.utils.toUtf8Bytes(message));
    const signature = await provider.provider.wc.signPersonalMessage([wcMessage, account]);
    return signature;
  }

  return provider.getSigner(account).signMessage(message);
};
