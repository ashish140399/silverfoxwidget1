import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Footer from './components/Footer';
import Navbar from './components/Navbar';
import Landing from './views/Landing';
import Home from './views/Home';
import Awakening from './views/Pages/Awakening';
import Duality from './views/Pages/Duality';
import Prologue from './views/Pages/Prologue';
import Resurrection from './views/Pages/Resurrection';
import Resurrectionmain from './views/Resurrection';
import About from './views/Pages/About';
import Choose from './views/Pages/Choose';
import styled from 'styled-components';
import { TweenMax } from 'gsap';
import Mint from './views/Mint';
import Shapebg from './components/Shapes/Shapebg';
import Name from './views/Name';
import Swap from './views/Swap';
import Sacrifice from './views/Sacrifice';
import { FormatQuote } from '@mui/icons-material';
import Faq from './views/Pages/Faq';
import Account from './views/Account';

const App = () => {
  // const cursor = document.querySelectorAll('.cursor'),
  //   follower = document.querySelectorAll('.cursor-follower');
  // console.log(cursor);

  // let posX = 0,
  //   posY = 0;

  // const mouseX = 0,
  //   mouseY = 0;

  // TweenMax.to({}, 0.016, {
  //   repeat: -1,
  //   onRepeat: function () {
  //     posX += (mouseX - posX) / 9;
  //     posY += (mouseY - posY) / 9;

  //     TweenMax.set(follower, {
  //       css: {
  //         left: posX - 12,
  //         top: posY - 12,
  //       },
  //     });

  //     TweenMax.set(cursor, {
  //       css: {
  //         left: mouseX,
  //         top: mouseY,
  //       },
  //     });
  //   },
  // });

  return (
    <SiteWrapper>
      <Shapebg />
      <BrowserRouter>
        <Navbar />
        <Routes>
          {/* <Route path="/" element={<Landing />} /> */}
          <Route path="/home" element={<Home />} />
          <Route path="/mint" element={<Mint />} />
          <Route path="/name" element={<Name />} />
          <Route path="/swap" element={<Swap />} />
          <Route path="/sacrifice" element={<Sacrifice />} />
          <Route path="/resur" element={<Resurrectionmain />} />
          <Route path="/account" element={<Account />} />

          {/* Sub Pages */}
          <Route path="/prologue" element={<Prologue />} />
          <Route path="/awakening" element={<Awakening />} />
          <Route path="/duality" element={<Duality />} />
          <Route path="/resurrection" element={<Resurrection />} />
          <Route path="/about" element={<About />} />
          <Route path="/" element={<Choose />} />
          <Route path="/faq" element={<Faq />} />
        </Routes>
        {/* <Footer /> */}
      </BrowserRouter>
    </SiteWrapper>
  );
};

const SiteWrapper = styled.div``;

export default App;
