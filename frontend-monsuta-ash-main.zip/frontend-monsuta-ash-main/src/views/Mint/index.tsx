import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings } from '../style';
import { Button } from '@mui/material';

const Mint = () => {
  const [congrats, setCongrats] = useState(true);
  return (
    <PageWrapper maxWidth="sm">
      {congrats && (
        <MintNFT>
          <Headings>Mint your NFT</Headings>
          <p className="para">
            Of all the yōkai that lurk in the deepest darkest corners of the Orient, it is the Monsutā who are the most feared and by far
            the most formidable… <br /> <br /> Which Monsutā will you master in your quest for ultimate power?
          </p>
          <div className="mintbx">
            <div className="mintbxheading">
              <Headings>Mint Monsutā</Headings>
              <div className="rght">
                <div>
                  Price <span>0.2 ETH</span>
                </div>
                <div>
                  Max per <span>5 transaction</span>
                </div>
              </div>
            </div>
            <div className="mintcontent">
              <div className="lftcnt">
                <div className="bx active">1</div>
                <div className="bx">2</div>
                <div className="bx">3</div>
                <div className="bx">4</div>
                <div className="bx">5</div>
              </div>
              <div className="rghtcnt">
                <Button variant="contained">Mint your NFT</Button>
              </div>
            </div>
          </div>
        </MintNFT>
      )}
      {!congrats && (
        <Congrats>
          {' '}
          <Headings>Congratulations</Headings>
          <p className="para">
            Welcome to the dream. You have unleashed X Monsutas. To view your Monsuta NFTs, press proceed to the 'My Account' section below.
          </p>
          <Button variant="contained">My Account</Button>
        </Congrats>
      )}
    </PageWrapper>
  );
};
const Congrats = styled.div`
  button {
    margin: auto;
    display: block;
    margin-top: 30px;
  }
`;
const MintNFT = styled.div`
  .mintbx {
    margin-top: 70px;
    .mintbxheading {
      display: flex;
      align-items: Center;
      justify-content: space-between;
      margin-bottom: 30px;

      ${Headings} {
        text-align: left;
        font-size: 28px;
        margin-bottom: 0;
      }
      @media (max-width: 600px) {
        flex-direction: column;
        ${Headings} {
          margin-bottom: 10px;
        }
      }
      .rght {
        display: flex;
        align-items: Center;
        div {
          margin-left: 18px;
        }
        span {
          color: #b32d32;
        }
      }
    }
    .mintcontent {
      display: flex;
      align-items: Center;
      justify-content: space-between;
      .lftcnt {
        display: flex;
        align-items: Center;
        .bx {
          border: 1px solid #65637e;
          color: #65637e;
          border-radius: 50%;
          margin-right: 12px;
          width: 30px;
          height: 30px;
          display: flex;
          align-items: center;
          justify-content: center;
          &.active {
            color: #b32d32;
            border-color: #b32d32;
          }
        }
      }
      .rghtcnt {
      }
      @media (max-width: 600px) {
        flex-direction: column;
        .lftcnt {
          margin-bottom: 20px;
        }
      }
    }
  }
`;

const PageWrapper = styled(Container)`
  display: flex !important;
  align-items: Center;
  justify-content: Center;
  ${Headings} {
    text-align: center;
  }
  .para {
    color: #65637e;
    text-align: center;
  }
`;
export default Mint;
