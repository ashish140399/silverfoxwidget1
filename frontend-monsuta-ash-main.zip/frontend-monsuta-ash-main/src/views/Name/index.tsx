import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings } from '../style';
import { Button, Input } from '@mui/material';
import Grid from '@mui/material/Grid';
import MonsutaCard from '../../components/MonsutaCard';

const Name = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Name your Monsutā</Headings>
      <p className="para">
        Before naming your Monsutā please read the naming rules and information: <b>Chapter 1 - Baptism</b>
      </p>
      <div className="reqrbal">
        <div>
          Required <b>500 Favor</b>
        </div>
        <div>
          Balance <b>0 Favor</b>
        </div>
      </div>

      <Grid container spacing={2} className="selectbx">
        <Grid item xs={12}>
          <div className="selhead">Select Monsutā</div>
        </Grid>

        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(index => (
          <Grid item xs={12} sm={6} md={4} lg={3}>
            <MonsutaCard />{' '}
          </Grid>
        ))}
      </Grid>
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: left;
  }
  .para {
    color: #65637e;
    text-align: left;
  }
  .reqrbal {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
    margin-top: 30px !important;
    div {
      margin-right: 20px;
    }
  }

  .selectbx {
    .selhead {
      font-weight: 500;
      font-size: 20px;
      line-height: 38px;
      display: flex;
      align-items: center;
      color: #090627;
    }
  }
`;

export default Name;
