import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings, StepsBox } from '../style';
import { Button, Input } from '@mui/material';
import Grid from '@mui/material/Grid';
import MonsutaCard from '../../components/MonsutaCard';
import image01 from '../../assets/namecard.png';
import image02 from '../../assets/namecard2.png';
import monsuta from '../../assets/monsuta.png';

const Resurrectionmain = () => {
  const [steponeimg, setSteponeimg] = useState(null);
  const [steptwotmg, setSteptwotmg] = useState(null);
  const [stepthreeimg, setStepthreeimg] = useState(null);
  const [stepfourtmg, setStepfourtmg] = useState(null);
  const [evolvevalues, setEvolvevalues] = useState(false);

  const clearValues = () => {
    setSteponeimg(null);
    setSteptwotmg(null);
    setStepthreeimg(null);
    setStepfourtmg(null);
    setEvolvevalues(false);
  };

  const evolveValues = () => {
    setStepthreeimg(monsuta);
    setStepfourtmg(monsuta);
    setEvolvevalues(true);
  };
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Resurrection</Headings>
      <p className="para">
        Before resurrecting your Monsutās please read the resurrection rules and information: <b>Chapter 3: Resurrection</b>
      </p>
      <div className="reqrbal">
        <div>
          Required <b>(2) Monsutā</b> and <b>750 Favor</b>
        </div>
        <div>
          Balance <b>(0) Monsutā</b> and <b>0 Favor</b>
        </div>
      </div>

      <StepsBox container spacing={4} className="swapbx">
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            {' '}
            <Headings>Step 1</Headings>
            <p>Select Soulbound Monsutā</p>
          </div>
          <div className={`cardbxx ${steponeimg ? 'filled' : ''}`} onClick={() => setSteponeimg(image01)}>
            <Headings>Select from the list below</Headings>
            <img src={image01} className="placeholdercard" alt="" />
            {steponeimg && <img src={steponeimg} className={`bximg ${evolvevalues ? 'fade' : ''}`} alt="" />}
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Step 2</Headings>
            <p>Select Evolved Monsutā</p>
          </div>
          <div className={`cardbxx ${steptwotmg ? 'filled' : ''}`} onClick={() => setSteptwotmg(image02)}>
            <Headings>Select from the list below</Headings>
            <img src={image01} className="placeholdercard" alt="" />
            {steptwotmg && <img src={steptwotmg} className={`bximg ${evolvevalues ? 'fade' : ''}`} alt="" />}
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Monsutā</Headings>
          </div>
          <div className="cardbxx">
            <img src={image01} className="placeholdercard" alt="" />
            {steponeimg && steptwotmg && <img src={stepfourtmg} className="bximg" alt="" />}
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Monsutā</Headings>
          </div>
          <div className="cardbxx">
            <img src={image01} className="placeholdercard" alt="" />
            {steponeimg && steptwotmg && <img src={stepthreeimg} className="bximg" alt="" />}
          </div>
        </Grid>
      </StepsBox>
      <Grid container spacing={2} className="selectbx">
        <Grid item xs={12}>
          <div className="selhead">Select Monsutā</div>
        </Grid>

        {[0, 1, 2, 3, 4, 5, 6, 7].map(index => (
          <Grid item xs={12} sm={6} md={4} lg={3}>
            <MonsutaCard />{' '}
          </Grid>
        ))}
      </Grid>
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: left;
  }
  .para {
    color: #65637e;
    text-align: left;
  }
  .reqrbal {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
    margin-top: 30px !important;
    div {
      margin-right: 20px;
    }
  }

  .swapbx {
    margin-top: 30px;
    .swapgrid {
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }
    .headingstop {
      margin-bottom: 30px;
      height: 65px;
      @media (max-width: 900px) {
        height: auto;
      }
    }
    .cardbxx {
      border: 2px dashed #65637e;
      border-radius: 20px;
      overflow: hidden;
      position: relative;
      &.gradientbx {
        overflow: visible;
      }
      ${Headings} {
        opacity: 0.1;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        width: calc(100% - 30px);
        font-size: 36px;
      }
      img {
        width: 100%;
      }
      &.filled {
        border: 2px solid transparent;
      }
      .placeholdercard {
        opacity: 0;
        position: relative;
        z-index: -2;
      }
      .bximg {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        &.fade {
          opacity: 0.7;
        }
      }
    }
    &.iptsbx {
      color: #090627;
      font-size: 18px;
      font-weight: 600;
      .MuiInput-root {
        width: 100%;
        color: #090627 !important;
        margin: 10px 0 !important;
        margin-bottom: 8px !important;
      }
    }
  }

  .selectbx {
    margin-top: 20px;
    .selhead {
      font-weight: 500;
      font-size: 20px;
      line-height: 38px;
      display: flex;
      align-items: center;
      color: #090627;
    }
  }
`;

export default Resurrectionmain;
