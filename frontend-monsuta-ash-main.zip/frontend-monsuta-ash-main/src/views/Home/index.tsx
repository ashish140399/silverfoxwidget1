import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings } from '../style';

const Home = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Wrapper>
        <Headings>Revolutionizing art and NFTs through multiversatility and lore activated tokenomics.</Headings>
        <p className="para">
          Monsuta is an ancient story that exists within a dream. A legend of monsters and beasts known as the yōkai (supernatural beings)
          from the deepest darkest corners of the Orient. Of all the yōkai, it was the Monsuta who were the most dreaded and by far the most
          powerful…
        </p>
        <ChaptersMap />
        <div className="info">No fiverr clipart. No outlandish Roadmap. Just real art with in built versatility.</div>
      </Wrapper>
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  display: flex !important;
  align-items: center;
  justify-content: center;
  ${Headings} {
    text-align: center;
    margin: auto;
  }
  .para {
    color: #65637e;
    text-align: center;
  }
  .chaptersmap {
    margin: 40px 0;
  }
  .info {
    text-align: center;
    font-weight: 400;
    font-size: 16px;
    color: #65637e;
  }
`;
const Wrapper = styled.div`
  max-width: var(--fullwidth);
`;
export default Home;
