import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings } from '../style';
import { createGlobalStyle } from 'styled-components';
import { MediumIcon, TwitterIcon } from '../../assets/icons';

const Landing = () => {
  return (
    <PageWrapper maxWidth="lg">
      <div className="content">
        <Headings>Monsutā</Headings>
        <p className="para">Revolutionizing art and NFTs through multiversatility and lore activated tokenomics.</p>
      </div>

      <div className="socicons">
        <a href="https://medium.com/@monsuta.art">
          <MediumIcon />
        </a>
        <a href="https://twitter.com/monsuta_art">
          <TwitterIcon />
        </a>
      </div>
      <GlobalStyle />
    </PageWrapper>
  );
};
const GlobalStyle = createGlobalStyle`
  .footermons, .navbarmons{
    display:none !important;
  }
`;

const PageWrapper = styled(Container)`
  display: flex !important;
  flex-direction: column;
  min-height: 100vh;
  align-items: Center;
  justify-content: Center;
  ${Headings} {
    text-align: center;
    margin: auto;
    font-size: 160px;
    font-weight: 700;
    color: #090627;
    line-height: 180px;
    @media screen and (max-width: 900px) {
      font-size: 100px;
      line-height: 150px;
    }
    @media screen and (max-width: 500px) {
      font-size: 70px;
      line-height: 80px;
    }
  }
  .para {
    color: #65637e;
    text-align: center;
    font-size: 18px;
  }
  .socicons {
    position: absolute;
    bottom: 28px;
    a {
      padding: 0 10px;
      svg {
        transform: scale(0.9);
      }
    }
  }
`;
export default Landing;
