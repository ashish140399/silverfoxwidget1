import styled from 'styled-components';
import Grid from '@mui/material/Grid';

export const Headings = styled.div`
  font-family: 'Playfair Display';
  font-style: normal;
  font-weight: 600;
  font-size: 64px;
  color: #090627;
  margin-bottom: 25px;
  @media screen and (max-width: 2000px) {
    font-size: 40px;
  }
`;

export const RulesBox = styled.div`
  border: 1px solid #65637e;
  border-radius: 20px;
  padding: 28px 20px;
  font-size: 16px;
  color: #65637e;
  min-height: 300px;
  position: relative;
  overflow: hidden;
  b {
    color: #65637e;
  }
  h3 {
    font-weight: 700;
    font-size: 20px;
    margin-bottom: 10px;
    color: #090627;
  }
  img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
  @media screen and (max-width: 2000px) {
  }
`;

export const StepsBox = styled(Grid)`
  margin-bottom: 30px;
  ${Headings} {
    font-size: 24px;
    line-height: unset;
    margin-bottom: 10px;
    font-weight: 700;
  }
  p {
    margin: 0;
  }
`;
