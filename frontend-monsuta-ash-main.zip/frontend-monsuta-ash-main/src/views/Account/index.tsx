import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings } from '../style';
import { Button, Input } from '@mui/material';
import Grid from '@mui/material/Grid';
import MonsutaCard from '../../components/MonsutaCard';

const Account = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Your Account</Headings>
      <p className="para">0x766546e237fd32c9e7а96d343b1вмb787e7cbb45</p>
      <div className="reqrbal">
        <div>
          Required <b>500 Favor</b>
        </div>
        <div>
          Balance <b>0 Favor</b>
        </div>
      </div>

      <div className="balancebx">
        <Headings className="selhead">Balances</Headings>
        <div className="balbx">
          <div className="brow">
            <div>Favor (0 claimable)</div>
            <div>0</div>
            <Button variant="contained">Claim Favor</Button>
          </div>
          <div className="brow">
            <div>Monsutā</div>
            <div>0</div>
            <Button variant="contained">Marketplace</Button>
          </div>
          <br />
          <div className="brow">
            <div>Generating</div>
            <div>
              10 <span>Favor / day</span>
            </div>
          </div>
        </div>
      </div>
      <Grid container spacing={2} className="selectbx">
        <Grid item xs={12}>
          <Headings className="selhead">Monsutas Owned</Headings>
        </Grid>

        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map(index => (
          <Grid item xs={12} sm={6} md={4} lg={3}>
            <MonsutaCard />{' '}
          </Grid>
        ))}
      </Grid>
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: left;
  }
  .para {
    color: #65637e;
    text-align: left;
  }
  .reqrbal {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
    margin-top: 30px !important;
    div {
      margin-right: 20px;
    }
  }
  .balancebx{
    margin-bottom:40px;
    .balbx{
      .brow{
        display:flex;
        align-items:center;
        margin-bottom:14px;
        div{
          width:200px;
          color: #090627;
          font-weight:600;
          &:first-child{
            font-weight:500;
            color: #65637E;
          }
        }
        button{
          padding:4px 20px !important;
          font-size:13px !important;
        }
        @media (max-width: 550px) {
          flex-flow:wrap;
          button{
            margin-top:10px
          }
        }

    }
  }
  
  .selectbx {
    .selhead {
      // font-weight: 500;
      // font-size: 20px;
      // line-height: 38px;
      // display: flex;
      // align-items: center;
      // color: #090627;
    }
  }
  ${Headings} {
    &.selhead{
      font-size: 28px !important;
      line-height: 38px;
    }
  }
  
`;

export default Account;
