import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings } from '../style';
import { Button, CircularProgress, Input } from '@mui/material';
import Grid from '@mui/material/Grid';
import { ArrowIcon, LinkextIcon, SwapIcon } from '../../assets/icons';
import image01 from '../../assets/namecard.png';
import image02 from '../../assets/namecard2.png';

const Swap = () => {
  const [openingnft, setOpeningnft] = useState('');
  const [closingnft, setClosingnft] = useState('');
  const [openingnftimg, setOpeningnftmg] = useState(image01);
  const [closingnftmg, setClosingnftmg] = useState(image02);
  const [approvestatus, setApprovestatus] = useState('open');
  const [tradestatus, setTradestatus] = useState('open');
  const [anotherguypov, setAnotherguypov] = useState(false);

  const swapfunction = () => {
    const temptext = openingnft;
    setOpeningnft(closingnft);
    setClosingnft(temptext);

    const tempimg = openingnftimg;
    setOpeningnftmg(closingnftmg);
    setClosingnftmg(tempimg);
  };

  const approveNdtradehandler = () => {
    if (approvestatus === 'open') {
      setApprovestatus('ongoing');
      setTimeout(() => {
        setApprovestatus('approved');
      }, 2000);
    }

    if (tradestatus === 'open' && approvestatus === 'approved') {
      console.log('insde');
      setTradestatus('ongoing');
      setTimeout(() => {
        setTradestatus('approved');
      }, 2000);
    }
  };
  const tradehandler = () => {
    console.log('trader');
  };
  return (
    <PageWrapper maxWidth="md">
      <SwapNFT>
        <Headings>SutāSwap</Headings>
        <p className="para">(Secure P2P swapping free of charge - just pay gas)</p>
        <a href="#">
          How to swap? <LinkextIcon />
        </a>
        <Grid container spacing={2} className="swapbx iptsbx">
          <Grid item xs={12} md={5}>
            Opening NFT
            <Input
              disableUnderline
              value={openingnft}
              onChange={e => setOpeningnft(e.target.value)}
              placeholder="OpenSea Link (What you have)"
            />
            <div className="cardbxx">
              <img src={openingnftimg} className="placeholdercard" alt="" />
              {openingnft && <img src={openingnftimg} className="bximg" alt="" />}
            </div>
          </Grid>
          <Grid item xs={12} md={2} className="swapgrid">
            <Button onClick={swapfunction}>
              <SwapIcon />
            </Button>
          </Grid>
          <Grid item xs={12} md={5}>
            Closing NFT
            <Input
              disableUnderline
              value={closingnft}
              onChange={e => setClosingnft(e.target.value)}
              placeholder="OpenSea Link (What you have)"
            />
            <div className="cardbxx">
              <img src={closingnftmg} className="placeholdercard" alt="" />
              {closingnft && <img src={closingnftmg} className="bximg" alt="" />}
            </div>
          </Grid>
        </Grid>

        <div className="controlsbx">
          {tradestatus === 'approved' ? null : (
            <Button
              variant="contained"
              className={`${approvestatus === 'ongoing' ? 'ongoing' : approvestatus === 'approved' ? 'approved' : ''}`}
              onClick={approveNdtradehandler}
            >
              {approvestatus === 'open' ? (
                anotherguypov ? (
                  'Approve closing'
                ) : (
                  'Approve opening'
                )
              ) : approvestatus === 'ongoing' ? (
                <>
                  Approving <CircularProgress size={20} />
                </>
              ) : approvestatus === 'approved' ? (
                <>
                  Approved <ArrowIcon />
                </>
              ) : null}
            </Button>
          )}
          <Button
            variant="contained"
            className={`${tradestatus === 'ongoing' ? 'ongoing' : tradestatus === 'approved' ? 'approved' : ''}`}
            onClick={approveNdtradehandler}
            disabled={!(approvestatus === 'approved')}
          >
            {tradestatus === 'open' ? (
              anotherguypov ? (
                'Trade NFT'
              ) : (
                'Open trade'
              )
            ) : tradestatus === 'ongoing' ? (
              <>
                {anotherguypov ? 'Trading NFT' : 'Opening trade'} <CircularProgress size={20} />
              </>
            ) : tradestatus === 'approved' ? (
              <>
                {anotherguypov ? 'Trade successful' : 'Trade Opened'} <ArrowIcon />
              </>
            ) : null}
          </Button>
        </div>

        <a href="#" className="powered">
          Powered by popswap <LinkextIcon />
        </a>
      </SwapNFT>
    </PageWrapper>
  );
};

const SwapNFT = styled.div`
  a {
    text-align: center;
    color: #090627 !important;
    display: block;
    margin: auto;
    font-weight: 500;

    svg {
      position: relative;
      margin-bottom: -7px;
      margin-left: 8px;
    }
    &.powered {
      font-weight: 400;
      color: #65637e;
      svg {
        path {
          fill: #65637e;
        }
      }
    }
  }
  .swapbx {
    margin-top: 30px;
    width: 100%;
    box-sizing: border-box;
    .swapgrid {
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      button {
        transform: translateY(100px);
      }
    }
    .cardbxx {
      border: 2px dashed #65637e;
      border-radius: 20px;
      overflow: hidden;
      position: relative;
      margin-top: 20px;
      img {
        width: 100%;
      }
      .placeholdercard {
        opacity: 0;
        position: relative;
        z-index: -2;
      }
      .bximg {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
      }
    }
    &.iptsbx {
      color: #090627;
      font-size: 18px;
      font-weight: 600;
      .MuiInput-root {
        width: 100%;
        color: #090627 !important;
        margin: 10px 0 !important;
        margin-bottom: 8px !important;
      }
      @media (max-width: 900px) {
        max-width: 500px;
        margin: auto;
        .swapgrid {
          padding: 40px 0;
          button {
            transform: translateY(0px) rotate(90deg);
          }
        }
        .MuiGrid-item {
          padding-left: 0;
        }
      }
    }
  }
  .controlsbx {
    display: flex;
    justify-content: center;
    margin-top: 30px;
    margin-bottom: 30px;
    button {
      min-width: 150px;
      margin: 0 10px;
      &.ongoing {
        opacity: 0.6;
        .MuiCircularProgress-root {
          margin-left: 8px;
          color: #fff !important;
        }
      }
      &.approved {
        border-color: #2db342 !important;
        background: #2db342 !important;
      }
    }
    @media (max-width: 600px) {
      flex-direction: column;
      button {
        width: 100%;
        margin: auto;
        margin-bottom: 20px;
        max-width: 300px;
        display: block;
      }
    }
  }
`;

const PageWrapper = styled(Container)`
  display: flex !important;
  align-items: Center;
  justify-content: Center;
  ${Headings} {
    text-align: center;
  }
  .para {
    color: #65637e;
    text-align: center;
  }
`;
export default Swap;
