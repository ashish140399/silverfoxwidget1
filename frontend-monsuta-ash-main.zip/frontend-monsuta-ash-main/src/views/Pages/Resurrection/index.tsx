import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings, RulesBox } from '../../style';
import Grid from '@mui/material/Grid';
import { Button } from '@mui/material';

const Resurrection = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Chapter 3: Resurrection </Headings>
      <Grid container spacing={2} className="bannersec">
        <Grid item xs={12}>
          <img src={require('../../../assets/resurrection1.png')} alt="" />
        </Grid>
      </Grid>
      <Grid container spacing={2} className="infosec">
        <Grid item xs={12}>
          <Headings>The fate of every Monsutā is in the hands of their Master.</Headings>
        </Grid>
        <Grid item xs={12} lg={8}>
          <p>
            Only Soulbound Monsutās can be resurrected by using the ‘Resurrection’ function, returning the Monsutā back into the mortal
            realm.
          </p>
          <p>As the Soulbound Monsutā is bound to its Master only, it cannot be transferred to another Master in its Soulbound state.</p>
          <p>
            The Resurrection function will release the Soulbound Monsutā, and will grant Masters the ability to transfer their Monsutā once
            again.
          </p>
          <p>
            The cost? The Evolved Monsutā shall be returned from its evolved state back to its original form, surrendering its self for the
            salvation of its Soulbound counterpart. A powerful creature still, but a shadow of its former apex self.
          </p>
          <p>
            To select the option to ‘Resurrect’, Masters are required to select <b>both</b>, a Soulbound Monsutā NFT and an Evolved Monsutā
            NFT. <b>750 $FAVOR</b> is required and shall be consumed by the Gods as penance.
          </p>
        </Grid>
      </Grid>

      <Grid container spacing={4} className="rulessec">
        <Grid item xs={12}>
          <Headings>The Rules</Headings>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 1</h3>Only Soulbound and Evolved Monsutās can be selected for the option of Resurrection;
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 2</h3>Resurrection function costs <b>750 $FAVOR </b>(burned), and requires a minimum of{' '}
            <b>one (1) Evolved Monsutā NFT</b> and <b>one (1) Soulbound Monsutā NFT</b>;
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={6}>
          <RulesBox>
            <h3>Rule 3</h3>For Evolved Monsutā NFTs, the Resurrection function will transform your Monsutā artwork back from an Evolved
            Monsutā NFT to its original state;
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={6}>
          <RulesBox>
            <h3>Rule 4</h3>For Soulbound Monsutā NFTs, the Resurrection function will return your Monsutā back into the mortal realm,
            thereby deactivating Soulbound and allowing your Monsutā to be transferable once again. Your Monsutā’s artwork will return to
            its original state.
          </RulesBox>
        </Grid>

        <Grid item xs={12} lg={6}>
          <RulesBox>
            <img src={require('../../../assets/resurrection2.png')} alt="" />
          </RulesBox>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained">Resurrect Monsutā</Button>
        </Grid>
      </Grid>
      <ChaptersMap />
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: center;
  }
  .bannersec {
    margin-bottom: 80px;
    img {
      width: 100%;
      height: auto;
    }
    b {
      text-align: Center;
      margin: auto;
      display: block;
      margin-top: 14px;
    }
  }
  .infosec {
    margin-bottom: 80px;
    ${Headings} {
      text-align: left;
    }
    img {
      width: 100%;
      height: auto;
    }
    p {
      margin: 0;
      margin-bottom: 14px;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }
  .rulessec {
    margin-bottom: 100px;
    ${Headings} {
      text-align: left;
    }
  }
  .chaptersmap {
    margin: 50px 0;
  }
  button {
    @media (max-width: 900px) {
      display: block;
      margin: auto;
    }
  }
`;
export default Resurrection;
