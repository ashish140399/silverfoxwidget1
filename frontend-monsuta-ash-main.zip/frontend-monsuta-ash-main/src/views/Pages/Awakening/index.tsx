import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings, RulesBox } from '../../style';
import Grid from '@mui/material/Grid';
import { Button } from '@mui/material';

const Awakening = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Chapter 1: Baptism</Headings>
      <Grid container spacing={2} className="bannersec">
        <Grid item xs={12}>
          <img src={require('../../../assets/awaken1.png')} alt="" />
        </Grid>
      </Grid>
      <Grid container spacing={2} className="infosec">
        <Grid item xs={12}>
          <Headings>
            The beast steps forth out of the shadows, no longer just one of many, but one that answers the call of their name.
          </Headings>
          <div className="cntnt">
            <p>
              A Monsutā receiving its name is a powerful ritual, one that requires the favor of the Gods. Baptism is a rite of distinction,
              forging a loyalty and bond between Monsutā and Master.
            </p>
            <p>Monsutās that have successfully undergone the Baptism ritual will have their name etched in the blockchain.</p>
            <p>
              If deemed worthy of the Gods, simply scribe the Monsutā’s name in the input field, then select the “Set Name” button. This
              will execute a transaction, and <b>500 $FAVOR</b> shall be consumed by the Gods as penance. <br /> <br />
              <br />
              Never forget, the rare beast is one that is given a name.
              <br />
              <br />
              <br /> What will you name your Monsutā?
            </p>
          </div>
        </Grid>
      </Grid>

      <Grid container spacing={4} className="rulessec">
        <Grid item xs={12}>
          <Headings>The Rules</Headings>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 1</h3>It costs 500 $FAVOR to change the name of your Monsuta
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 2</h3>Used names can not be identical /Identical names are not permitted
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 3</h3>Maximum of 25 characters (including spaces)
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 4</h3>Character's uniqueness is case insensitive
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 5</h3>Alphanumeric characters only (numbers 0-9 and letters A-Z both uppercase and lowercase)
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 6</h3>No leading or trailing spaces
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 7</h3>Names can be recycled and immediately used after the original NFT name has been changed
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <img src={require('../../../assets/awaken2.png')} alt="" />
          </RulesBox>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained">Name Monsutā</Button>
        </Grid>
      </Grid>

      <ChaptersMap />
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: center;
  }
  .bannersec {
    margin: auto;
    margin-bottom: 30px;
    img {
      width: 100%;
      height: auto;
    }
    .imgalt {
      margin-top: 50px;
    }
  }
  .infosec {
    margin: auto;
    margin-bottom: 80px;
    max-width: 900px;

    img {
      width: 100%;
      height: auto;
    }
    p {
      margin: 0;
      margin-bottom: 22px;
      text-align: center;
      &:last-child {
        margin-bottom: 0;
      }
    }
    .cntnt {
      margin: auto;
      max-width: 800px;
    }
  }
  .rulessec {
    margin-bottom: 100px;
  }
  .chaptersmap {
    margin: 50px 0;
  }
  button {
    @media (max-width: 900px) {
      display: block;
      margin: auto;
    }
  }
`;
export default Awakening;
