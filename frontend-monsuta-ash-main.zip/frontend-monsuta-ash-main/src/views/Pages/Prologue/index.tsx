import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings } from '../../style';
import Grid from '@mui/material/Grid';
import { Button } from '@mui/material';

const Prologue = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Prologue: Mint </Headings>
      <Grid container spacing={2} className="bannersec">
        <Grid item xs={12}>
          <img src={require('../../../assets/pro1.png')} alt="" />
          <Headings className="imgalt">Enter the dream, and become the nightmare.</Headings>
        </Grid>
      </Grid>
      <Grid container spacing={8} className="infosec">
        <Grid item xs={12} md={8}>
          <p>
            The dream realm is home to 8888 unique and powerful Monsuta living in the deepest, darkest corners of the Orient. It is only
            those few deemed worthy that can enter the dream…
          </p>
          <p>
            A dreamer, if favored by the Gods, can mint a Monsuta for a price of <b>0.2 ETH</b>. A maximum of <b>5 Monsuta NFTs</b> can be
            minted per transaction.
          </p>
          <p>
            Once minted, a dreamer is guaranteed passage into the realm, a dangerous world governed by magic and riddled with all manner of
            monsters, beasts, and sinister yōkai.
          </p>
          <p>
            Every dreamer who mints a Monsuta NFT may claim <b>500 $FAVOR per Monsuta</b> as a gift from the old Gods and as a reward for
            securing their entry into the realm.
          </p>
          <p>
            A dreamer must allow themselves to be consumed by the fantasy on their new journey. It is the only way to become a master and
            truly harness the magic and colossal power of the Monsuta.
          </p>
          <p>One must touch the darkness to master their reality.</p>
          <Button variant="contained">Mint Monsutā</Button>
        </Grid>
        <Grid item xs={12} md={4}>
          <img src={require('../../../assets/pro2.png')} alt="" />
        </Grid>
      </Grid>
      <ChaptersMap />
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: center;
  }
  .bannersec {
    margin-bottom: 30px;
    margin-top: 30px;
    img {
      width: 100%;
      height: auto;
    }

    .imgalt {
      margin-top: 50px;
    }
  }
  .infosec {
    img {
      width: 100%;
      height: auto;
      @media (max-width: 900px) {
        max-width: 500px;
        display: block;
        margin: auto;
      }
    }
    p {
      margin: 0;
      margin-bottom: 14px;
      &:last-child {
        margin-bottom: 0;
      }
    }
    button {
      margin-top: 30px;
      @media (max-width: 900px) {
        display: block;
        margin: auto;
        margin-top: 30px;
      }
    }
  }
  .chaptersmap {
    margin: 50px 0;
  }
`;
export default Prologue;
