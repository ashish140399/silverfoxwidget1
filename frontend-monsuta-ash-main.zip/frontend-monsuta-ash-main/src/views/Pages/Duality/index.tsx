import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings, RulesBox } from '../../style';
import Grid from '@mui/material/Grid';
import { Button } from '@mui/material';

const Duality = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Chapter 2: Evolution</Headings>
      <Grid container spacing={2} className="bannersec">
        <Grid item xs={12}>
          <img src={require('../../../assets/duality1.png')} alt="" />
        </Grid>
      </Grid>
      <Grid container spacing={2} className="infosec">
        <Grid item xs={12}>
          <Headings>The path to evolution is a journey into forgotten and forsaken places.</Headings>
        </Grid>

        <Grid item xs={12} lg={9}>
          <p>Only the worthiest of Monsutā will be granted evolution by the Gods of the old world.</p>
          <br />
          <p>
            A Master, with enough FAVOR, can choose to sacrifice one of their Monsutās to the realm of the ‘Soulbound’, and select another
            Monsutā under their command to undergo evolution. The result, an unfathomable transformation, a mutation leading to the beast
            reaching its ultimate and inexorable form, an <b>Evolved Monsutā</b>.
          </p>
        </Grid>
        <Grid item xs={12} md={3}>
          <img src={require('../../../assets/duality2.png')} alt="" />
        </Grid>
      </Grid>

      <Grid container spacing={4} className="rulessec">
        <Grid item xs={12}>
          <Headings>The Rules</Headings>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 1</h3>A Master must be in command of at least <b>two</b> Monsuta and must sacrifice <b>one</b> of their Monsuta during
            the process of evolution (transformation)
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 2</h3>
            <b> One Monsutā NFT</b> must be chosen to be sacrificed during this ritual (becoming Soulbound), and another Monsutā NFT must be
            selected to be evolved;
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 3</h3>
            The process of ascension requires <b>250 $FAVOR;</b>
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 4</h3>Once a Monsutā has been sacrificed, that Monsutā will be <b>Soulbound</b> (i.e.your Monsutā cannot be transferred
            to other users in this state. You do not lose your Soul Monsutā NFT!);
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 5</h3>The result will be that one Monsutā NFT will be <b>Soulbound</b> and another Monsutā NFT will have undergone
            transformation into an Evolved Monsutā
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={3}>
          <RulesBox>
            <h3>Rule 6</h3>An <b>Evolved Monsutā </b>has a 3x boost and accumulates at <b>75 $FAVOR </b>per day, whilst a{' '}
            <b>Soulbound Monsutā</b> accumulates <b>NO $FAVOR</b>.
          </RulesBox>
        </Grid>
        <Grid item xs={12} lg={6}>
          <RulesBox>
            <img src={require('../../../assets/duality3.png')} alt="" />
          </RulesBox>
        </Grid>
        <Grid item xs={12}>
          <Button variant="contained">Name Monsutā</Button>
        </Grid>
      </Grid>
      <ChaptersMap />
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: center;
  }
  .bannersec {
    margin-bottom: 80px;
    img {
      width: 100%;
      height: auto;
    }
    b {
      text-align: Center;
      margin: auto;
      display: block;
      margin-top: 14px;
    }
  }
  .infosec {
    margin-bottom: 80px;

    img {
      width: 100%;
      height: auto;
    }
    p {
      margin: 0;
      margin-bottom: 14px;
      &:last-child {
        margin-bottom: 0;
      }
    }
  }
  .rulessec {
    margin-bottom: 100px;
    b {
      color: #000 !important;
    }
  }
  .chaptersmap {
    margin: 50px 0;
  }
  button {
    @media (max-width: 900px) {
      display: block;
      margin: auto;
    }
  }
`;
export default Duality;
