import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings } from '../../style';
import Grid from '@mui/material/Grid';
import { styled as muistyled } from '@mui/material/styles';
import ArrowForwardIosSharpIcon from '@mui/icons-material/ArrowForwardIosSharp';
import MuiAccordion, { AccordionProps } from '@mui/material/Accordion';
import MuiAccordionSummary, { AccordionSummaryProps } from '@mui/material/AccordionSummary';
import MuiAccordionDetails from '@mui/material/AccordionDetails';
import Typography from '@mui/material/Typography';
import { AddIcon } from '../../../assets/icons';

const Accordion = muistyled((props: AccordionProps) => <MuiAccordion disableGutters elevation={0} square {...props} />)(
  ({ theme }) => ({})
);

const AccordionSummary = muistyled((props: AccordionSummaryProps) => <MuiAccordionSummary expandIcon={<AddIcon />} {...props} />)(
  ({ theme }) => ({
    flexDirection: 'row-reverse',
    '& .MuiAccordionSummary-expandIconWrapper.Mui-expanded': {
      transform: 'rotate(135deg)',
    },
    '& .MuiAccordionSummary-content': {
      // marginLeft: theme.spacing(1),
    },
  })
);

const AccordionDetails = muistyled(MuiAccordionDetails)(({ theme }) => ({
  padding: theme.spacing(2),
}));

const Faq = () => {
  const [expanded, setExpanded] = React.useState<string | false>('panel1');

  const handleChange = (panel: string) => (event: React.SyntheticEvent, newExpanded: boolean) => {
    setExpanded(newExpanded ? panel : false);
  };

  return (
    <PageWrapper maxWidth="lg">
      <Headings>Frequently Asked Questions</Headings>
      <p className="para">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's</p>
      <div className="accordionbx">
        <Accordion expanded={expanded === 'panel1'} onChange={handleChange('panel1')}>
          <AccordionSummary aria-controls="panel1d-content" id="panel1d-header">
            <Typography>
              <Headings>What is Monsutā?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel2'} onChange={handleChange('panel2')}>
          <AccordionSummary aria-controls="panel2d-content" id="panel2d-header">
            <Typography>
              <Headings>What are Monsutā NFTs?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel3'} onChange={handleChange('panel3')}>
          <AccordionSummary aria-controls="panel3d-content" id="panel3d-header">
            <Typography>
              <Headings>Are $FAVOR tokens the same as Name Changing Token (NCT)?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel4'} onChange={handleChange('panel4')}>
          <AccordionSummary aria-controls="panel4d-content" id="panel4d-header">
            <Typography>
              <Headings>Are the contracts verified?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel5'} onChange={handleChange('panel5')}>
          <AccordionSummary aria-controls="panel5d-content" id="panel5d-header">
            <Typography>
              <Headings>What makes Monsutās different from others?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel6'} onChange={handleChange('panel6')}>
          <AccordionSummary aria-controls="panel6d-content" id="panel6d-header">
            <Typography>
              <Headings>What makes a Monsutā rare?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel7'} onChange={handleChange('panel7')}>
          <AccordionSummary aria-controls="panel7d-content" id="panel7d-header">
            <Typography>
              <Headings>How many Monsutās are there?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel8'} onChange={handleChange('panel8')}>
          <AccordionSummary aria-controls="panel8d-content" id="panel8d-header">
            <Typography>
              <Headings>How do I know which Monsutā I am buying?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>
        <Accordion expanded={expanded === 'panel9'} onChange={handleChange('panel9')}>
          <AccordionSummary aria-controls="panel9d-content" id="panel9d-header">
            <Typography>
              <Headings>Will I be able to trade my Monsutā after the sale?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel10'} onChange={handleChange('panel10')}>
          <AccordionSummary aria-controls="panel10d-content" id="panel10d-header">
            <Typography>
              <Headings>Can I conduct peer to peer trades on your website free of charge?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel11'} onChange={handleChange('panel11')}>
          <AccordionSummary aria-controls="panel11d-content" id="panel11d-header">
            <Typography>
              <Headings>How much does a Monsutā cost?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel12'} onChange={handleChange('panel12')}>
          <AccordionSummary aria-controls="panel12d-content" id="panel12d-header">
            <Typography>
              <Headings>How can I get more $FAVOR?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel13'} onChange={handleChange('panel13')}>
          <AccordionSummary aria-controls="panel13d-content" id="panel13d-header">
            <Typography>
              <Headings>How do I check and claim my $FAVOR?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel14'} onChange={handleChange('panel14')}>
          <AccordionSummary aria-controls="panel14d-content" id="panel14d-header">
            <Typography>
              <Headings>What can I spend my $FAVOR on?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel15'} onChange={handleChange('panel15')}>
          <AccordionSummary aria-controls="panel15d-content" id="panel15d-header">
            <Typography>
              <Headings>How do I know how rare my Monsutā is?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel16'} onChange={handleChange('panel16')}>
          <AccordionSummary aria-controls="panel16d-content" id="panel16d-header">
            <Typography>
              <Headings>Can I name my Monsutā anything?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel17'} onChange={handleChange('panel17')}>
          <AccordionSummary aria-controls="panel17d-content" id="panel17d-header">
            <Typography>
              <Headings>When can I name my Monsutā?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel18'} onChange={handleChange('panel18')}>
          <AccordionSummary aria-controls="panel18d-content" id="panel18d-header">
            <Typography>
              <Headings>Do I have to change my Monsutā’s name?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel19'} onChange={handleChange('panel19')}>
          <AccordionSummary aria-controls="panel19d-content" id="panel19d-header">
            <Typography>
              <Headings>Will others see my Monsutā on the website?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel20'} onChange={handleChange('panel20')}>
          <AccordionSummary aria-controls="panel20d-content" id="panel20d-header">
            <Typography>
              <Headings>Where can I view my Monsutā NFTs?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel21'} onChange={handleChange('panel21')}>
          <AccordionSummary aria-controls="panel21d-content" id="panel21d-header">
            <Typography>
              <Headings>Do I own the Monsutā after minting it?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel22'} onChange={handleChange('panel22')}>
          <AccordionSummary aria-controls="panel22d-content" id="panel22d-header">
            <Typography>
              <Headings>Are there secondary sale royalties?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>

        <Accordion expanded={expanded === 'panel23'} onChange={handleChange('panel23')}>
          <AccordionSummary aria-controls="panel23d-content" id="panel23d-header">
            <Typography>
              <Headings>My question is not on the FAQ?</Headings>
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography>
              Monsutā NFTs are a generative collection of 8888 unique digital artworks available on the Ethereum blockchain. By owning a
              Monsutā NFT, and participating in the Monsutā ecosystem, holders can unlock multiple versions (multiple variations of the
              artwork) of their NFT.
            </Typography>
          </AccordionDetails>
        </Accordion>
      </div>
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: left;
    margin-bottom: 0;
  }

  .para {
    margin-bottom: 0px;
    text-align: left;
    padding: 0;
    color: #65637e;
  }
  .accordionbx {
    margin-left: 18px;
    margin-top: 30px;
    .MuiPaper-root {
      background: Transparent;
    }
    .MuiAccordion-root {
      margin: 14px 0;
      &::before {
        display: none;
      }
    }
    ${Headings} {
      font-size: 27px;
      margin-bottom: 0;
    }
    .MuiAccordionSummary-content {
      margin: 0;
    }
    .MuiAccordionDetails-root {
      padding-top: 0;
      padding-bottom: 0;
      color: #65637e;
    }
    .MuiAccordionSummary-expandIconWrapper {
      margin-left: -18px;
      position: relative;
      left: -15px;
    }
  }
`;
export default Faq;
