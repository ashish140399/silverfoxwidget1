import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings } from '../../style';
import Grid from '@mui/material/Grid';

const About = () => {
  return (
    <PageWrapper maxWidth="lg">
      <Headings>The Legend of the Monsutā</Headings>
      <Grid container spacing={2} className="bannersec">
        <Grid item xs={12}>
          <img src={require('../../../assets/about1.png')} alt="" />
          <div className="para">
            <p>
              There is a realm that exists within a dream, a highly ritualistic world that is governed by powerful magic. It is a world that
              reflects the ancient Orient but one where monsters, beasts, and the supernatural exist in its deepest and darkest corners. It
              is only the old Gods of this realm that hold true power over the yōkai (the supernatural).
            </p>
            <p>
              On a bone chilling winter night, a young Emperor grew restless, teetering on the edge of sleep and reality. It was at this
              moment that he was struck with a vision, a crystal-clear apparition.
            </p>
          </div>
          <Headings>
            He was instructed that if he were to capture a Monsutā, the most dreaded and powerful of all the yōkai, he would wield its
            power.
          </Headings>
          <div className="para">
            <p>
              The Emperor's name would never be forgotten, his reign never challenged, and his legacy forever forged in stone. Against the
              advice of his onymoji, the Emperor set off, venturing deep into the inky darkness that lay on the outskirts of the realm.
              After capturing his first, he moved quickly to ensnare a second, and now he has many Monsutā under his command. The passage of
              time has marched forwards, and
            </p>
          </div>
          <Headings>the Emperor has become renowned throughout the realm, as a collector of chaos and nightmares.</Headings>
          <img src={require('../../../assets/about2.png')} className="middleimg" alt="" />
          <div className="para">
            <p>
              No matter the power and fear the Emperor reigned, satisfaction seemed forever out of reach. The mere acquisition of Monsutās,
              though many, was no longer enough. The Emperor craved a power that could only be granted by the Gods.
            </p>
            <p>
              It was rumored that the Emperor, long having dismissed the guidance of the wise onymoji, had brokered a deal with the old Gods
              of his own fruition, a blood sacrifice in exchange for the darkest and most powerful magic.
            </p>
          </div>
          <Headings>The Gods demanded that a Monsutā be cast to the realm of the Soulbound,</Headings>
          <div className="para">
            <p>
              and in return, another Monsutā under the Emperor’s command would be granted an unfathomable evolution, a mutation leading to
              the beast reaching its ultimate and inexorable form, an Evolved Monsutā. The Emperor stood in awe, humbled by the old Gods’
              magic. He now commanded the most powerful of Monsutās. This God favored beast, the most formidable of all the yōkai, was a
              reflection of evolution in its absolute incarnation. The Emperor had unlocked a mightiness that would take his rule beyond the
              realm within the dream. His ambition now set on piercing the veil of a greater reality.
            </p>
          </div>
        </Grid>
      </Grid>
      <ChaptersMap />
    </PageWrapper>
  );
};

const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: center;
    margin-bottom: 0;
  }
  .bannersec {
    margin-bottom: 0px;
    margin-top: 30px;
    img {
      width: 100%;
      height: auto;
    }
  }
  .para {
    margin: auto;
    margin-bottom: 0px;
    text-align: Center;
    max-width: 800px;
    color: #65637e;

    display: block;
    p {
      color: #65637e;
      margin: 0;
      margin: 30px 0;
    }
  }
  .middleimg {
    margin-top: 30px;
  }
  .chaptersmap {
    margin: 50px 0;
  }
`;
export default About;
