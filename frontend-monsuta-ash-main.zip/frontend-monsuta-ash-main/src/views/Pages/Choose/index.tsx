import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../../components/ChaptersMap';
import { Headings } from '../../style';
import { createGlobalStyle } from 'styled-components';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';

const Choose = () => {
  return (
    <PageWrapperplus>
      <PageWrapper maxWidth="lg">
        <Grid container spacing={5} className="choosescreen">
          <Grid item xs={12} md={6}>
            <Link className="capsbx" to="/home">
              Enter the dream and become the nightmare
              <img src={require('../../../assets/red_capsule.png')} alt="" />
            </Link>
          </Grid>
          <Grid item xs={12} md={6}>
            <a className="capsbx" href="https://careers.mcdonalds.com/choose-location">
              Remain in mediocrity and embrance your reality
              <img src={require('../../../assets/blue_capsule.png')} alt="" />
            </a>
          </Grid>
        </Grid>
        <img src={require('../../../assets/8888.png')} className="bglog" alt="" />
      </PageWrapper>
      <GlobalStyle />
    </PageWrapperplus>
  );
};
const PageWrapperplus = styled.div``;
const GlobalStyle = createGlobalStyle`
  .footermons, .navbarmons{
    display:none;
  }
`;

const PageWrapper = styled(Container)`
  display: flex !important;
  align-items: center;
  justify-content: Center;
  min-height: 100vh;
  position: Relative;
  .bglog {
    position: absolute;
    width: 98%;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    z-index: -1;
    @media (max-width: 900px) {
      transform: translate(-50%, -50%) rotate(90deg);
    }
  }
  .choosescreen {
    position: relative;
    .capsbx {
      display: flex;
      align-items: center;
      justify-content: Center;
      flex-direction: column;
      font-style: normal;
      font-weight: 700;
      font-size: 40px;
      line-height: 64px;
      display: flex;
      align-items: center;
      text-align: center;
      font-family: 'Playfair Display', serif;
      color: #000000;
      max-width: 280px;
      margin: auto;
      text-decoration: none;
      img {
        width: 80px;
        margin-top: 40px;
      }
      @media (max-width: 900px) {
        max-width: 300px;
        font-size: 40px;
      }

      @media (max-width: 500px) {
        font-size: 30px;
      }
    }
    &::before {
      position: absolute;
      width: 2px;
      height: 80vh;
      background: rgba(101, 99, 126, 0.3);
      content: '';
      top: 50%;
      left: calc(50% + 10px);
      transform: translate(-50%, -50%);
      z-index: -1;
      @media (max-width: 900px) {
        top: calc(50% + 30px);
        left: 50%;
        width: 80vw;
        height: 2px;
      }
    }
  }
`;
export default Choose;
