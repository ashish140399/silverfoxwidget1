import React, { useState } from 'react';
import styled from 'styled-components';
import Container from '@mui/material/Container';
import ChaptersMap from '../../components/ChaptersMap';
import { Headings, StepsBox } from '../style';
import { Button, Input } from '@mui/material';
import Grid from '@mui/material/Grid';
import MonsutaCard from '../../components/MonsutaCard';
import image01 from '../../assets/namecard.png';
import image02 from '../../assets/namecard2.png';

const Sacrifice = () => {
  const [steponeimg, setSteponeimg] = useState(null);
  const [steptwotmg, setSteptwotmg] = useState(null);
  const [stepthreeimg, setStepthreeimg] = useState(null);
  const [stepfourtmg, setStepfourtmg] = useState(null);
  const [evolvevalues, setEvolvevalues] = useState(false);

  const clearValues = () => {
    setSteponeimg(null);
    setSteptwotmg(null);
    setStepthreeimg(null);
    setStepfourtmg(null);
    setEvolvevalues(false);
  };

  const evolveValues = () => {
    setStepthreeimg(image02);
    setStepfourtmg(image01);
    setEvolvevalues(true);
  };
  return (
    <PageWrapper maxWidth="lg">
      <Headings>Sacrifice to evolve</Headings>
      <p className="para">
        Before evolving your Monsutā please read the duality rules and information: <b>Chapter 2 - Evolution</b>
      </p>
      <div className="reqrbal">
        <div>
          Required <b>5(2) Monsutā</b> and <b>250 Favor</b>
        </div>
        <div>
          Balance <b>(0) Monsutā</b> and <b>0 Favor</b>
        </div>
      </div>

      <StepsBox container spacing={4} className="stepbox swapbx">
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Step 1</Headings>
            <p>Select a Monsutā to Sacrifice</p>
          </div>
          <div className={`cardbxx ${steponeimg ? 'filled' : ''}`} onClick={() => setSteponeimg(image01)}>
            <Headings>Select from the list below</Headings>
            <img src={image01} className="placeholdercard" alt="" />
            {steponeimg && <img src={steponeimg} className={`bximg ${evolvevalues ? 'fade' : ''}`} alt="" />}
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Step 2</Headings>
            <p>Select a Monsutā to Evolve</p>
          </div>
          <div className={`cardbxx ${steptwotmg ? 'filled' : ''}`} onClick={() => setSteptwotmg(image02)}>
            <Headings>Select from the list below</Headings>
            <img src={image01} className="placeholdercard" alt="" />
            {steptwotmg && <img src={steptwotmg} className={`bximg ${evolvevalues ? 'fade' : ''}`} alt="" />}
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Soulbound Monsutā</Headings>
          </div>
          <div className={'cardbxx'} onClick={() => setSteptwotmg(image02)}>
            <img src={image01} className="placeholdercard" alt="" />
            {steponeimg && steptwotmg && <img src={stepfourtmg} className="bximg" alt="" />}
          </div>
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <div className="headingstop">
            <Headings>Evolved Monsutā</Headings>
          </div>
          <div className="cardbxx gradientbx">
            <img src={image01} className="placeholdercard" alt="" />
            {evolvevalues && (
              <AnimatedBorderbx>
                <div className="gradient-border" id="box">
                  {' '}
                  {steponeimg && steptwotmg && <img src={stepthreeimg} className="bximg" alt="" />}
                </div>
              </AnimatedBorderbx>
            )}
          </div>
        </Grid>
        <Grid item xs={12} className="bottombtns">
          <Button variant="outlined" onClick={clearValues}>
            Clear
          </Button>
          <Button variant="contained" disabled={steponeimg && steptwotmg ? false : true} onClick={evolveValues}>
            Evolve Monsuta
          </Button>
        </Grid>
      </StepsBox>
      <Grid container spacing={2} className="selectbx">
        <Grid item xs={12}>
          <div className="selhead">Select Monsutā</div>
        </Grid>

        {[0, 1, 2, 3, 4, 5, 6, 7].map(index => (
          <Grid item xs={12} sm={6} md={4} lg={3}>
            <MonsutaCard />{' '}
          </Grid>
        ))}
      </Grid>
    </PageWrapper>
  );
};

const AnimatedBorderbx = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  .gradient-border {
    --borderWidth: 5px;
    background: #f5f5f5;
    position: relative;
    border-radius: 20px;
    height: 100%;
  }
  .gradient-border:after {
    content: '';
    position: absolute;
    top: calc(-1 * var(--borderWidth));
    left: calc(-1 * var(--borderWidth));
    height: calc(100% + var(--borderWidth) * 2);
    width: calc(100% + var(--borderWidth) * 2);
    background: linear-gradient(60deg, #f79533, #f37055, #ef4e7b, #a166ab, #5073b8, #1098ad, #07b39b, #6fba82);
    border-radius: 20px;
    z-index: -1;
    animation: animatedgradient 3s ease alternate infinite;
    background-size: 300% 300%;
    filter: blur(10px);
  }

  @keyframes animatedgradient {
    0% {
      background-position: 0% 50%;
    }
    50% {
      background-position: 100% 50%;
    }
    100% {
      background-position: 0% 50%;
    }
  }
`;
const PageWrapper = styled(Container)`
  ${Headings} {
    text-align: left;
  }
  .para {
    color: #65637e;
    text-align: left;
  }
  .reqrbal {
    display: flex;
    align-items: center;
    margin-bottom: 30px;
    margin-top: 30px !important;
    div {
      margin-right: 20px;
    }
  }

  .swapbx {
    margin-top: 30px;
    .headingstop {
      margin-bottom: 30px;
      height: 65px;
      @media (max-width: 900px) {
        height: auto;
      }
    }
    .swapgrid {
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }
    .cardbxx {
      border: 2px dashed #65637e;
      border-radius: 20px;
      overflow: hidden;
      position: relative;
      &.gradientbx {
        overflow: visible;
      }
      ${Headings} {
        opacity: 0.1;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        text-align: center;
        width: calc(100% - 30px);
        font-size: 36px;
      }
      img {
        width: 100%;
      }
      &.filled {
        border: 2px solid transparent;
      }
      .placeholdercard {
        opacity: 0;
        position: relative;
        z-index: -2;
      }
      .bximg {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        &.fade {
          opacity: 0.7;
        }
      }
    }
    &.iptsbx {
      color: #090627;
      font-size: 18px;
      font-weight: 600;
      .MuiInput-root {
        width: 100%;
        color: #090627 !important;
        margin: 10px 0 !important;
        margin-bottom: 8px !important;
      }
    }
    .bottombtns {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 30px;
      // margin-bottom: 20px;
      button {
        min-width: 200px;
      }
    }
  }

  .selectbx {
    margin-top: 20px;
    .selhead {
      font-weight: 500;
      font-size: 20px;
      line-height: 38px;
      display: flex;
      align-items: center;
      color: #090627;
    }
  }
`;

export default Sacrifice;
