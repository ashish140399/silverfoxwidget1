import { useEffect, useState } from 'react';
import Countdown from 'react-countdown';
import { useIsBrowserTabActive } from '../contexts/RefreshContext';

export function useMintWindow(startTime?: number, endTime?: number) {
  const isBrowserTabActiveRef = useIsBrowserTabActive();
  const [countDown, setCountDown] = useState(null);

  const renderBeforeStart = ({ hours, minutes, seconds, completed }) => {
    if (completed) {
      return null;
    } else {
      // Render a countdown
      return (
        <span className="countdown-text">
          24 hour mint window opens in:{' '}
          <span className="digital7-text">
            {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </span>
        </span>
      );
    }
  };

  const renderBeforeEnd = ({ hours, minutes, seconds, completed }) => {
    if (completed) {
      return null;
    } else {
      // Render a countdown
      return (
        <span className="countdown-text">
          Tribe can only be minted for the next{' '}
          <span className="digital7-text">
            {String(hours).padStart(2, '0')}:{String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
          </span>{' '}
          and then mint will be closed forever.
        </span>
      );
    }
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (isBrowserTabActiveRef) {
        const now = Math.floor(new Date().getTime() / 1000);

        if (startTime && now < startTime) {
          setCountDown(<Countdown date={startTime * 1000} daysInHours={true} renderer={renderBeforeStart} zeroPadTime={2} />);
        } else if (now >= startTime && now < endTime) {
          setCountDown(<Countdown date={endTime * 1000} daysInHours={true} renderer={renderBeforeEnd} zeroPadTime={2} />);
        } else {
          setCountDown(null);
        }
      }
    }, 1000);

    return () => clearInterval(interval);
  }, [isBrowserTabActiveRef, startTime, endTime]);

  return countDown;
}
