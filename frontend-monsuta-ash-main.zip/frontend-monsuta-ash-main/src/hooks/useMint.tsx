import { useEffect, useState } from 'react';
import { getMonsutaContract, simpleRpcProvider } from '../utils/contracts';
import useRefresh from './useRefresh';
import { useWeb3React } from '@web3-react/core';
import { formatEther } from 'ethers/lib/utils';
import multicall from '../utils/multicall';
import MonsutaAbi from '../config/abi/Monsuta.json';

const useMint = (index: number) => {
  const total = 14000;
  const priceForPublic = '0.2';

  const [available, setAvailable] = useState(3854);
  const [totalSupply, setTotalSupply] = useState(0);
  const [costPerMint, setCostPerMint] = useState(priceForPublic);
  const [isSaleActive, setIsSaleActive] = useState(true);
  const [isClaimActive, setIsClaimActive] = useState(false);

  const { account } = useWeb3React();
  const { slowRefresh } = useRefresh();

  useEffect(() => {
    const fetch = async () => {
      const contract = getMonsutaContract(simpleRpcProvider);

      const calls = [
        {
          address: contract.address,
          name: 'currentTokenId',
          params: [],
        },
        {
          address: contract.address,
          name: 'totalSupply',
          params: [],
        },
        {
          address: contract.address,
          name: 'isSaleActive',
          params: [],
        },
        {
          address: contract.address,
          name: 'isClaimActive',
          params: [],
        },
      ];

      // if (account) {
      //   const proof = getMerkleProof(whitelist, account);
      //   calls.push({
      //     address: contract.address,
      //     name: 'costForMint',
      //     params: [1, account, proof],
      //   });
      // }

      const result = await multicall(MonsutaAbi, calls, simpleRpcProvider);

      setAvailable(total - result[0][0].toNumber());
      setTotalSupply(result[1][0].toNumber());
      setIsSaleActive(result[2][0]);
      setIsClaimActive(result[3][0]);

      if (account) {
        setCostPerMint(formatEther(result[4][0]));
      }
    };

    fetch();
  }, [slowRefresh, account, index]);

  return {
    costPerMint,
    total,
    totalSupply,
    available,
    isSaleActive,
    isClaimActive,
  };
};

export default useMint;
