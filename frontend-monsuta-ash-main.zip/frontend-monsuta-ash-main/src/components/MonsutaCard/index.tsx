import React, { useState } from 'react';
import styled from 'styled-components';
import { Button, Input } from '@mui/material';
import Grid from '@mui/material/Grid';

const MonsutaCard = () => {
  const [status, setStatus] = useState(true);
  const [name, setName] = useState('');
  const [nametemp, setNametemp] = useState('');
  const [mosueenterstate, setMosueenterstate] = useState(false);

  return (
    <Card onMouseEnter={() => setMosueenterstate(true)} onMouseLeave={() => setMosueenterstate(false)}>
      <img src={require('../../assets/namecard.png')} className="card" alt="" />
      <div className={`contentcrd ${mosueenterstate ? 'showit' : ''}`}>
        {name ? (
          <div className="nameset">{name}</div>
        ) : (
          <div className={`nameunset ${nametemp === 'monsuta' ? 'green' : 'red'}`}>
            Enter Name
            <Input disableUnderline onChange={e => setNametemp(e.target.value)} />
            <div className="status">{nametemp === 'monsuta' ? 'Valid name' : 'Invalid name'}</div>
            <Button variant="contained" disabled={nametemp === 'monsuta' ? false : true} onClick={() => setName(nametemp)}>
              Assign Name
            </Button>
          </div>
        )}
      </div>
      <div className={`overlay ${mosueenterstate ? 'showit' : ''}`} />
    </Card>
  );
};

const Card = styled.div`
  position: relative;
  border-radius: 20px;
  overflow: hidden;
  .card {
    width: 100%;
  }
  .overlay {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    height: 100%;
    width: 100%;
    background: linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, #000000 100%);
    z-index: 2;
    opacity: 0;
    transition: all 0.2s ease;
    &.showit {
      opacity: 1;
    }
  }
  .contentcrd {
    position: absolute;
    bottom: -200px;
    width: 100%;
    left: 0;
    right: 0;
    padding: 0px 20px 24px 20px;
    box-sizing: border-box;
    z-index: 3;
    transition: all 0.4s ease;

    &.showit {
      bottom: 0;
    }
    .nameset {
      color: #fff;
      text-align: center;
    }
    .nameunset {
      color: #fff;
      .MuiInput-root {
        width: 100%;
        color: #fff !important;
        margin: 10px 0 !important;
        margin-bottom: 8px !important;
      }
      button {
        width: 100%;
        margin-top: 16px;
      }
      &.green {
        .MuiInput-root {
          border-color: #00b812;
        }
        .status {
          color: #00b812;
        }
      }
      &.red {
        .MuiInput-root {
          border-color: #ff0000;
        }
        .status {
          color: #ff0000;
        }
      }
    }
  }
`;
export default MonsutaCard;
