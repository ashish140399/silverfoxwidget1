import styled from 'styled-components';
import Grid from '@mui/material/Grid';
import { Link } from 'react-router-dom';
const ChaptersMap = () => {
  return (
    <Wrapper className="chaptersmap">
      <Grid container spacing={2}>
        <Grid item xs={12} md={3}>
          <OvalShape to="/prologue">
            Prologue: Mint
            <img src={require('../../assets/chmap1.png')} alt="" />
          </OvalShape>
        </Grid>
        <Grid item xs={12} md={3}>
          <OvalShape to="/awakening">
            Chapter 1: Awakening
            <img src={require('../../assets/chmap2.png')} alt="" />
          </OvalShape>
        </Grid>
        <Grid item xs={12} md={3}>
          <OvalShape to="/duality">
            Chapter 2: Duality
            <img src={require('../../assets/chmap3.png')} alt="" />
          </OvalShape>
        </Grid>
        <Grid item xs={12} md={3}>
          <OvalShape to="/resurrection">
            Chapter 3: Resurrection
            <img src={require('../../assets/chmap4.png')} alt="" />
          </OvalShape>
        </Grid>
      </Grid>
    </Wrapper>
  );
};

const Wrapper = styled.div`
  .MuiGrid-item {
    display: flex;
    justify-content: center;
  }
`;
const OvalShape = styled(Link)`
  color: #65637e;
  font-family: 'Playfair Display', serif;
  text-decoration: none;
  font-size: 24px;
  width: 205px;
  height: 350px;
  border: 1px solid #65637e;
  border-radius: 50%;
  display: flex;
  justify-content: center;
  align-items: center;
  transform: Scale(-1) rotate(13.6deg);
  writing-mode: vertical-lr;
  font-weight: 600;
  position: relative;
  cursor: pointer;
  overflow: hidden;
  @media (max-width: 900px) {
    margin-bottom: 20px;
    &:last-child {
      margin-bottom: 0;
    }
  }
  img {
    position: absolute;
    top: 0;
    left: -5px;
    height: 100%;
    width: 215px;
    opacity: 0;
    transform: Scale(-1.2) rotate(-9.6deg);
    transition: all 0.3s ease;
    background: rgba(0, 0, 0, 0);
  }
  &:hover {
    border: 1px solid transparent;
    img {
      opacity: 1;
      transform: Scale(-1) rotate(-9.6deg);
      background: rgba(0, 0, 0, 0.2);
    }
  }
`;
export default ChaptersMap;
