import * as React from 'react';
import AppBar from '@mui/material/AppBar';
import Box from '@mui/material/Box';
import Divider from '@mui/material/Divider';
import Drawer from '@mui/material/Drawer';
import IconButton from '@mui/material/IconButton';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import MenuIcon from '@mui/icons-material/Menu';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import styled from 'styled-components';
import { Headings } from '../../views/style';
import { Link } from 'react-router-dom';
import { CloseIcon, InstaIcon, MediumIcon, TwitterIcon } from '../../assets/icons';
import WalletConnect from '../WalletConnect';
// import { WalletConnect } from '../header/WalletConnect';

interface Props {
  /**
   * Injected by the documentation to work in an iframe.
   * You won't need it on your project.
   */
  window?: () => Window;
}

const drawerWidth = 340;

export default function DrawerAppBar(props: Props) {
  const { window } = props;
  const [mobileOpen, setMobileOpen] = React.useState(false);

  const handleDrawerToggle = () => {
    setMobileOpen(!mobileOpen);
  };

  const leftstrip = (
    <LeftStrip className="strips">
      <div className="bsbx">
        <img src={require('../../assets/eth.png')} alt="" />
        Hashmasks: <b>62</b>
      </div>
      <div className="bsbx">
        CyberKongz: <b>1.20</b>
      </div>
      <div className="bsbx">
        BAYC: <b>3.50</b>
      </div>
      <div className="bsbx">
        <img src={require('../../assets/degod.png')} alt="" />
        DeGods: <b>62</b>
      </div>
    </LeftStrip>
  );
  const drawer = (
    <Box onClick={handleDrawerToggle} sx={{ textAlign: 'center' }} className="sidedrawer">
      <button onClick={handleDrawerToggle} className="closeicon">
        <CloseIcon />
      </button>
      <div className="topdrawer">
        <Typography variant="h6" sx={{ my: 0 }}>
          <Headings className="logonav">Monsutā Ecosystem</Headings>
        </Typography>

        <List className="navitems">
          <div className="aboutss">
            <div className="bx">
              <Link className="heads" to="/about">
                About
              </Link>
              <p>Delve into the legend of the Monsutā</p>
            </div>
            <div className="bx">
              <Link className="heads" to="/mint">
                Mint
              </Link>
              <p>Mint your Monsutā and enter the dream</p>
            </div>
            <div className="bx">
              <Link className="heads" to="/swap">
                SutāSwap
              </Link>
              <p>Safe and secure peer 2 peer trading with SutāSwap</p>
            </div>
          </div>

          <div className="normals">
            <div className="heads">Chapters</div>
            <div className="bx">
              <Link to="/prologue">Prologue: Mint</Link>
            </div>
            <div className="bx">
              <Link to="/awakening">Chapter 1: Baptism</Link>
            </div>
            <div className="bx">
              <Link to="/duality">Chapter 2: Evolution</Link>
            </div>
            <div className="bx">
              <Link to="/resurrection">Chapter 3: Resurrection</Link>
            </div>
          </div>
          <div className="normals">
            <div className="heads">Rituals</div>
            <div className="bx">
              <Link to="/">Baptism ceremony</Link>
            </div>
            <div className="bx">
              <Link to="/sacrifice">Evolution Ceremony</Link>
            </div>
            <div className="bx">
              <Link to="/resur">Resurrection Ceremony</Link>
            </div>
          </div>
          <div className="normals">
            <Link className="heads" to="/">
              Contacts
            </Link>
          </div>
          <div className="normals stripsbx">{leftstrip}</div>
        </List>
      </div>
      <div className="bottomdrawer">
        <div className="socicons">
          <a href="https://medium.com/@monsuta.art">
            <MediumIcon />
          </a>
          <a href="https://twitter.com/monsuta_art">
            <TwitterIcon />
          </a>
          <a href="https://twitter.com/monsuta_art">
            <InstaIcon />
          </a>
        </div>
        <WalletConnect />
      </div>
    </Box>
  );

  const container = window !== undefined ? () => window().document.body : undefined;

  return (
    <NavBarWrapper className="navbarmons">
      <NavStrip>
        {leftstrip}
        <div className="socicons">
          <a href="https://medium.com/@monsuta.art">
            <MediumIcon />
          </a>
          <a href="https://twitter.com/monsuta_art">
            <TwitterIcon />
          </a>
          <a href="https://twitter.com/monsuta_art">
            <InstaIcon />
          </a>
        </div>
      </NavStrip>
      <NavbarBox sx={{ display: 'flex' }}>
        <AppBar component="nav" className="madnavbar" elevation={0} position="relative">
          <Toolbar style={{ padding: 0 }} className="navitems">
            <div className="mobiletoolbar">
              <div className="rightmenu">
                <WalletConnect />
                <IconButton color="inherit" aria-label="open drawer" edge="start" onClick={handleDrawerToggle} sx={{ mr: 2 }}>
                  <MenuIcon />
                </IconButton>
              </div>
              <Headings className="logonav">Monsutā</Headings>
            </div>
          </Toolbar>
        </AppBar>
        <Box component="nav">
          <Drawer
            container={container}
            anchor="right"
            variant="temporary"
            open={mobileOpen}
            onClose={handleDrawerToggle}
            className="drawerpaper"
            ModalProps={{
              keepMounted: true, // Better open performance on mobile.
            }}
            sx={{
              display: { sm: 'block' },
              '& .MuiDrawer-paper': {
                boxSizing: 'border-box',
                width: drawerWidth,
                padding: '0px',
              },
            }}
          >
            {drawer}
          </Drawer>
        </Box>
      </NavbarBox>
      {/* <div className="idediv"></div> */}
    </NavBarWrapper>
  );
}

const NavBarWrapper = styled.div`
  margin-bottom: 40px;
  @media (max-width: 900px) {
    margin-bottom: 80px;
  }
  .idediv {
    position: absolute;
    background: red;
    width: 200px;
    right: 0;
    top: 0;
    height: 165px;
  }
`;

const LeftStrip = styled.div`
  display: flex;
  align-items: center;
  .bsbx {
    display: flex;
    align-items: center;
    margin-right: 20px;
    img {
      margin-right: 8px;
      margin-bottom: -4px;
    }
    b {
      margin-left: 5px;
      font-weight: 500;
    }
  }
`;

const NavStrip = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;

  background: #f1efed;
  border-bottom: 1px solid rgba(0, 0, 0, 0.1);
  padding: 8px 50px;
  margin-bottom: 12px;
  @media (max-width: 800px) {
    display: none;
  }

  .socicons {
    margin-left: -10px;
    display: flex;
    align-items: center;
    a {
      padding: 0 5px;
      svg {
        transform: scale(0.7);
      }
    }
  }
`;

const NavbarBox = styled(Box)`
  padding: 0 50px;
  @media (max-width: 900px) {
    padding: 0 16px;
    padding-top: 15px;
  }
  * {
    color: #65637e;
  }
  .connectbtn {
    @media (max-width: 500px) {
      display: none;
    }
  }
  .madnavbar {
    background-color: transparent !important;

    .logonav {
      color: #090627;
      margin-bottom: 0;
    }
    .connectbtn {
      margin-right: 30px;
    }
  }

  .mobiletoolbar {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-direction: row-reverse;

    .MuiIconButton-root {
      width: 30px;
      height: 30px;
    }
    .MuiIconButton-edgeStart {
      margin-right: 0;
      i {
        font-size: 16px;
      }
    }
    .rightmenu {
      display: flex;
      align-items: center;
    }
  }
`;
