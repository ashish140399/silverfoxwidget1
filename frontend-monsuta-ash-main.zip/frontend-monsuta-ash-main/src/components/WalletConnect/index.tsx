import * as React from 'react';
import { Button } from '@mui/material';
import styled from 'styled-components';
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { Headings } from '../../views/style';
import { AccountIcon, ArrowDownIcon, CloseIcon, LogoutIcon } from '../../assets/icons';
import { connectorLocalStorageKey, useActiveWeb3React } from '../../hooks';
import useAuth from '../../hooks/useAuth';
import { ConnectorNames } from '../../utils/web3React';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import { Link } from 'react-router-dom';

const WalletConnect = () => {
  const { account } = useActiveWeb3React();
  const { login } = useAuth();
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = event => {
    // eslint-disable-next-line
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  const onAuth = (connector: ConnectorNames) => {
    login(connector);
    window.localStorage.setItem(connectorLocalStorageKey, connector);
    setInfomodal(false);
  };

  const [infomodal, setInfomodal] = React.useState(false);
  const style = {
    position: 'absolute',
    top: '40%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '90%',
    maxWidth: 500,
    bgcolor: 'background.paper',
    border: 0,
    borderRadius: 5,
    boxShadow: 24,
    p: 3,
  };

  return (
    <>
      {account ? (
        <ButtonWrapper className="connectbtn">
          {' '}
          <Button
            id="basic-button"
            aria-controls={open ? 'basic-menu' : undefined}
            aria-haspopup="true"
            aria-expanded={open ? 'true' : undefined}
            onClick={handleClick}
            variant="outlined"
          >
            <div className="user"> {account}</div>
            <ArrowDownIcon />
          </Button>
          <Menu
            id="basic-menu"
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            MenuListProps={{
              'aria-labelledby': 'basic-button',
            }}
          >
            <MenuItem onClick={handleClose}>
              <Link to="/account">
                <AccountIcon />
                Account
              </Link>
            </MenuItem>
            <MenuItem onClick={handleClose}>
              <LogoutIcon />
              Logout
            </MenuItem>
          </Menu>
        </ButtonWrapper>
      ) : (
        <Button variant="contained" className="connectbtn" onClick={() => setInfomodal(true)}>
          Connect Wallet
        </Button>
      )}
      <Modal
        open={infomodal}
        onClose={() => setInfomodal(false)}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <ModalWrapper>
            <div className="headingmodal">
              <Headings>Connect your wallet</Headings>
              <button onClick={() => setInfomodal(false)} className="closeicon">
                <CloseIcon />
              </button>
            </div>
            <div className="modalcontent">
              <div
                className="bxxm"
                onClick={() => {
                  onAuth(ConnectorNames.Injected);
                }}
              >
                <div className="imgwer">
                  {' '}
                  <img src={require('../../assets/meta.png')} alt="" />
                </div>{' '}
                Metamask
              </div>

              <div
                className="bxxm"
                onClick={() => {
                  onAuth(ConnectorNames.WalletConnect);
                }}
              >
                <div className="imgwer">
                  {' '}
                  <img src={require('../../assets/walletconnect.png')} alt="" />
                </div>{' '}
                WalletConnect
              </div>
            </div>
          </ModalWrapper>
        </Box>
      </Modal>
    </>
  );
};

const ButtonWrapper = styled.div`
  .MuiButton-outlined {
    margin-right: 18px;
    color: #65637e !important;
    border-color: #65637e !important;
    .user {
      display: block;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 80px;
      margin-right: 8px;
    }
  }
`;
const ModalWrapper = styled.div`
  color: #090627;
  .headingmodal {
    margin-bottom: 30px;
    position: Relative;
    ${Headings} {
      margin-bottom: 0;
      font-size: 24px;
    }
    .closeicon {
      border: 0;
      transform-origin: center center;
      position: absolute;
      top: 50%;
      transform: translateY(-50%) scale(0.6);
      right: 0px;
      cursor: pointer;
      background: transparent;
    }
  }
  .bxxm {
    background: #f3f3f3;
    border-radius: 10px;
    display: flex;
    align-items: center;
    font-weight: 500;
    padding: 20px 28px;
    margin-bottom: 14px;
    cursor: pointer;
    border: 1px solid transparent;
    &:hover {
      border: 1px solid #b32d32;
    }
    .imgwer {
      width: 40px;
    }
    img {
      height: 24px;
      margin-bottom: -3px;
    }
    &:first-child {
    }
    &:last-child {
      margin-bottom: 0;
      img {
        width: 24px;
        height: auto;
      }
    }
  }
`;
export default WalletConnect;
