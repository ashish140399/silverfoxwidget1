import styled from 'styled-components';

const Footer = () => {
  return <div className="footermons">Footer</div>;
};

export default Footer;
