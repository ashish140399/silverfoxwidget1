import React from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import styled from 'styled-components';

const Shapebg = () => {
  return (
    <SiteWrapper>
      <div className="shapecrcl shape1"></div>
      <div className="shapecrcl shape2"></div>
    </SiteWrapper>
  );
};

const SiteWrapper = styled.div`
  .shapecrcl {
    width: 80vw;
    height: 80vh;
    position: fixed;
    z-index: -111;
    overflow: hidden;
    &::before {
      position: absolute;
      content: '';
      width: 30vw;
      height: 30vh;
      background: #ffdbb8;
      opacity: 0.6;
      filter: blur(120px);
      border-radius: 50%;
    }
  }
  .shape1 {
    top: 0;
    left: 0;
    &::before {
      top: -10vh;
      left: -10vw;
    }
  }
  .shape2 {
    bottom: 0;
    right: 0;
    &::before {
      right: -10vw;
      bottom: -10vh;
    }
  }
`;

export default Shapebg;
