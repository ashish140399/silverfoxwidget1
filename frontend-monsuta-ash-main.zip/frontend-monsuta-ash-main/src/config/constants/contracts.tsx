const contracts = {
  multiCall: {
    1: '0xeefba1e63905ef1d7acba5a8513c70307c1ce441',
    10: '0x5BA1e12693Dc8F9c48aAD8770482f4739bEeD696',
  },
  monsuta: {
    10: '0x191585dc18180Fa656d3D7117943F32c184bFFf7',
  },
  registry: {
    10: '0x23AA8CF0B87cE52da57695E7B93769Cd06286D49',
  },
  favor: {
    10: '0x26300651DeB7ca4e8e87dbDa37A26419bFa2cfED',
  },
};

export default contracts;
