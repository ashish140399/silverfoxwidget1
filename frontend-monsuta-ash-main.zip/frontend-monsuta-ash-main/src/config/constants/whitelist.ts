const whitelist = [];

export default whitelist;
